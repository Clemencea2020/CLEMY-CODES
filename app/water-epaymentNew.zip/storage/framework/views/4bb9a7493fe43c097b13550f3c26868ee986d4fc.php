<h2 class="font-semibold text-xl text-gray-800 leading-tight">
    <?php echo e(__('Dashboard')); ?>

    <a href="<?php echo e(url('/dashboard')); ?>" class="text-sm text-gray-700 underline">Dashboard</a>
    <a href="<?php echo e(url('/clients')); ?>" class="text-sm text-gray-700 underline">Clients</a>
    <a href="<?php echo e(url('/meters')); ?>" class="text-sm text-gray-700 underline">Meters</a>
    <a href="<?php echo e(url('/bills')); ?>" class="text-sm text-gray-700 underline">Bills</a>
    <a href="<?php echo e(url('/water-price')); ?>" class="text-sm text-gray-700 underline">WATER price per unit</a>
</h2><?php /**PATH C:\xampp\htdocs\water-epayment\resources\views/header.blade.php ENDPATH**/ ?>