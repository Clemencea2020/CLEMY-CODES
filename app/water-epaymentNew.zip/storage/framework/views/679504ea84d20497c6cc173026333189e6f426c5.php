<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
      <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <table class="table-auto w-full ">
                      <thead>
                        <tr>
                          <th class="text-left">ID</th>
                          <th class="text-left">Client Name</th>
                          <th class="text-left">Meter Code Id</th>
                          <th class="text-left">Previous reading</th>
                          <th class="text-left">Present reading</th>
                          <th class="text-left">Price/unit</th>
                          <th class="text-left">Amount</th>
                          <th class="text-left">Option</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if($bills->count() > 0): ?>
                            <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($bill->id); ?></td>
                                    <td><?php echo e($bill->client->names); ?></td>
                                    <td><?php echo e($bill->meter_id); ?></td>
                                    <td><?php echo e($bill->previousreading); ?></td>
                                    <td><?php echo e($bill->presentreading); ?></td>
                                    <td><?php echo e($bill->priceunit); ?></td>
                                    <td><?php echo e($bill->amount); ?></td>
                                    <td>
                                      <a href="<?php echo e(url('/bills/'.$bill->id.'/my-bill')); ?>">View</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                              <td colspan="4">No meters</td>
                            </tr>
                        <?php endif; ?>
                      </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\water-epayment\resources\views/bill/index.blade.php ENDPATH**/ ?>