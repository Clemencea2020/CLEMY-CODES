<h2 class="font-semibold text-xl text-gray-800 leading-tight">
    {{ __('Dashboard') }}
    <a href="{{ url('/dashboard') }}" class="text-sm text-gray-700 underline">Dashboard</a>
    <a href="{{ url('/clients') }}" class="text-sm text-gray-700 underline">Clients</a>
    <a href="{{ url('/meters') }}" class="text-sm text-gray-700 underline">Meters</a>
    <a href="{{ url('/bills') }}" class="text-sm text-gray-700 underline">Bills</a>
    <a href="{{ url('/water-price') }}" class="text-sm text-gray-700 underline">WATER price per unit</a>
</h2>